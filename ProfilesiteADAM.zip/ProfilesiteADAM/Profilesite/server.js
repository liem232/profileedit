const express = require('express');
const session = require('express-session');
const sqlite3 = require('sqlite3').verbose();
const multer = require('multer');
const path = require('path');
const bcrypt = require('bcryptjs');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'));
app.use('/uploads', express.static('uploads'));

app.use(session({
    secret: 'your-secret-key',
    resave: false,
    saveUninitialized: true,
    cookie: { secure: false }
}));

const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, 'uploads/');
    },
    filename: function (req, file, cb) {
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
        cb(null, 'profile-' + uniqueSuffix + path.extname(file.originalname));
    }
});

const upload = multer({
    storage: storage,
    limits: { fileSize: 5 * 1024 * 1024 }, // 5MB
    fileFilter: function (req, file, cb) {
        const filetypes = /jpeg|jpg|png|gif/;
        const mimetype = filetypes.test(file.mimetype);
        const extname = filetypes.test(path.extname(file.originalname).toLowerCase());
        
        if (mimetype && extname) {
            return cb(null, true);
        }
        cb(new Error('Только изображения разрешены!'));
    }
});

const db = new sqlite3.Database('./database.db', (err) => {
    if (err) {
        console.error('Ошибка подключения к базе данных:', err);
    } else {
        console.log('Подключение к SQLite установлено');
        initializeDatabase();
    }
});

function initializeDatabase() {
    db.run(`CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        email TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        role TEXT NOT NULL DEFAULT 'user',
        profile_image TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )`);

    db.all("PRAGMA table_info(users)", (err, columns) => {
        if (err) {
            console.error('Ошибка проверки структуры таблицы users:', err);
            return;
        }

        const hasRoleColumn = Array.isArray(columns) && columns.some((c) => c && c.name === 'role');
        if (!hasRoleColumn) {
            db.run("ALTER TABLE users ADD COLUMN role TEXT NOT NULL DEFAULT 'user'", (alterErr) => {
                if (alterErr) {
                    console.error('Ошибка добавления колонки role:', alterErr);
                    return;
                }
                console.log("Колонка role добавлена в таблицу users");
            });
        } else {
            db.serialize(() => {
                db.run("UPDATE users SET role = 'admin' WHERE role = 'role1'");
                db.run("UPDATE users SET role = 'user' WHERE role = 'role2'");
                db.run("UPDATE users SET role = 'manager' WHERE role = 'role3'");
                db.run("UPDATE users SET role = 'guest' WHERE role = 'role4'");
                db.run("UPDATE users SET role = 'user' WHERE role IS NULL OR role = ''");
            });
        }
    });
}

function isAuthenticated(req, res, next) {
    if (req.session.userId) {
        next();
    } else {
        res.status(401).json({ error: 'Требуется авторизация' });
    }
}

function requireRole(allowedRoles) {
    const roles = Array.isArray(allowedRoles) ? allowedRoles : [allowedRoles];
    return (req, res, next) => {
        if (!req.session.userId) {
            return res.status(401).json({ error: 'Требуется авторизация' });
        }

        db.get('SELECT role FROM users WHERE id = ?', [req.session.userId], (err, row) => {
            if (err) {
                return res.status(500).json({ error: 'Ошибка базы данных' });
            }
            if (!row) {
                return res.status(404).json({ error: 'Пользователь не найден' });
            }

            const userRole = row.role;
            if (userRole === 'admin') {
                req.userRole = userRole;
                return next();
            }

            if (!roles.includes(userRole)) {
                return res.status(403).json({ error: 'Недостаточно прав' });
            }

            req.userRole = userRole;
            next();
        });
    };
}

app.post('/api/register', async (req, res) => {
    try {
        const { username, email, password, role } = req.body;
        const allowedRoles = ['admin', 'user', 'manager', 'guest'];
        const normalizedRole = allowedRoles.includes(role) ? role : 'user';

        db.get('SELECT id FROM users WHERE username = ? OR email = ?', [username, email], async (err, row) => {
            if (err) {
                return res.status(500).json({ error: 'Ошибка базы данных' });
            }

            if (row) {
                return res.status(400).json({ error: 'Пользователь с таким именем или email уже существует' });
            }

            const hashedPassword = await bcrypt.hash(password, 10);

            db.run('INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, ?)', 
                [username, email, hashedPassword, normalizedRole], 
                function(err) {
                    if (err) {
                        return res.status(500).json({ error: 'Ошибка создания пользователя' });
                    }

                    req.session.userId = this.lastID;
                    res.status(201).json({ 
                        message: 'Регистрация успешна',
                        userId: this.lastID,
                        role: normalizedRole
                    });
                }
            );
        });
    } catch (error) {
        res.status(500).json({ error: 'Ошибка сервера' });
    }
});

app.post('/api/login', (req, res) => {
    const { username, password } = req.body;

    db.get('SELECT * FROM users WHERE username = ?', [username], async (err, user) => {
        if (err) {
            return res.status(500).json({ error: 'Ошибка базы данных' });
        }

        if (!user) {
            return res.status(401).json({ error: 'Неверные учетные данные' });
        }

        const isValidPassword = await bcrypt.compare(password, user.password);

        if (!isValidPassword) {
            return res.status(401).json({ error: 'Неверные учетные данные' });
        }

        req.session.userId = user.id;
        res.json({ 
            message: 'Авторизация успешна',
            user: {
                id: user.id,
                username: user.username,
                email: user.email,
                role: user.role,
                profileImage: user.profile_image
            }
        });
    });
});

app.get('/api/profile', isAuthenticated, (req, res) => {
    db.get('SELECT id, username, email, role, profile_image, created_at, updated_at FROM users WHERE id = ?', 
        [req.session.userId], 
        (err, user) => {
            if (err) {
                return res.status(500).json({ error: 'Ошибка базы данных' });
            }

            if (!user) {
                return res.status(404).json({ error: 'Пользователь не найден' });
            }

            res.json({ user });
        }
    );
});

app.get('/api/role', isAuthenticated, (req, res) => {
    db.get('SELECT role FROM users WHERE id = ?', [req.session.userId], (err, row) => {
        if (err) {
            return res.status(500).json({ error: 'Ошибка базы данных' });
        }
        if (!row) {
            return res.status(404).json({ error: 'Пользователь не найден' });
        }
        res.json({ role: row.role });
    });
});

app.put('/api/profile', isAuthenticated, (req, res) => {
    const { username, email } = req.body;

    db.get('SELECT role FROM users WHERE id = ?', [req.session.userId], (roleErr, roleRow) => {
        if (roleErr) {
            return res.status(500).json({ error: 'Ошибка базы данных' });
        }
        if (!roleRow) {
            return res.status(404).json({ error: 'Пользователь не найден' });
        }

        const role = roleRow.role;
        if (role !== 'admin' && role !== 'manager') {
            return res.status(403).json({ error: 'Недостаточно прав' });
        }

        db.get('SELECT id FROM users WHERE (username = ? OR email = ?) AND id != ?', 
            [username, email, req.session.userId], 
            (err, row) => {
                if (err) {
                    return res.status(500).json({ error: 'Ошибка базы данных' });
                }

                if (row) {
                    return res.status(400).json({ error: 'Имя пользователя или email уже заняты' });
                }

                db.run('UPDATE users SET username = ?, email = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?', 
                    [username, email, req.session.userId], 
                    function(err) {
                        if (err) {
                            return res.status(500).json({ error: 'Ошибка обновления профиля' });
                        }

                        res.json({ 
                            message: 'Профиль обновлен',
                            user: { username, email }
                        });
                    }
                );
            }
        );
    });
});

app.post('/api/profile/upload-photo', isAuthenticated, (req, res, next) => {
    db.get('SELECT role FROM users WHERE id = ?', [req.session.userId], (roleErr, roleRow) => {
        if (roleErr) {
            return res.status(500).json({ error: 'Ошибка базы данных' });
        }
        if (!roleRow) {
            return res.status(404).json({ error: 'Пользователь не найден' });
        }

        const role = roleRow.role;
        if (role !== 'admin' && role !== 'manager') {
            return res.status(403).json({ error: 'Недостаточно прав' });
        }

        next();
    });
}, upload.single('profileImage'), (req, res) => {
    if (!req.file) {
        return res.status(400).json({ error: 'Файл не загружен' });
    }

    const profileImage = '/uploads/' + req.file.filename;

    db.run('UPDATE users SET profile_image = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?', 
        [profileImage, req.session.userId], 
        function(err) {
            if (err) {
                return res.status(500).json({ error: 'Ошибка обновления фото' });
            }

            res.json({ 
                message: 'Фото профиля обновлено',
                profileImage: profileImage
            });
        }
    );
});

app.post('/api/logout', (req, res) => {
    req.session.destroy((err) => {
        if (err) {
            return res.status(500).json({ error: 'Ошибка выхода' });
        }
        res.json({ message: 'Выход выполнен успешно' });
    });
});

app.get('/api/check-auth', (req, res) => {
    if (req.session.userId) {
        db.get('SELECT role FROM users WHERE id = ?', [req.session.userId], (err, row) => {
            if (err) {
                return res.status(500).json({ error: 'Ошибка базы данных' });
            }
            res.json({ authenticated: true, userId: req.session.userId, role: row ? row.role : null });
        });
    } else {
        res.json({ authenticated: false });
    }
});

app.get('/role1', requireRole(['admin']), (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'role1.html'));
});

app.get('/role2', requireRole(['user']), (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'role2.html'));
});

app.get('/role34', requireRole(['manager', 'guest']), (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'role34.html'));
});

app.listen(PORT, () => {
    console.log(`Сервер запущен на http://localhost:${PORT}`);
});