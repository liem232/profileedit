class ProfileSystem {
    constructor() {
        this.initializeElements();
        this.bindEvents();
        this.checkAuth();
    }

    initializeElements() {
      
        this.loginForm = document.getElementById('login-form');
        this.registerForm = document.getElementById('register-form');
        this.profileSection = document.getElementById('profile');
        
        this.loginUsername = document.getElementById('loginUsername');
        this.loginPassword = document.getElementById('loginPassword');
        this.registerUsername = document.getElementById('registerUsername');
        this.registerEmail = document.getElementById('registerEmail');
        this.registerPassword = document.getElementById('registerPassword');
        
       
        this.profileImage = document.getElementById('profileImage');
        this.profileUsername = document.getElementById('profileUsername');
        this.profileEmail = document.getElementById('profileEmail');
        this.editUsername = document.getElementById('editUsername');
        this.editEmail = document.getElementById('editEmail');
        this.imageUpload = document.getElementById('imageUpload');
        

        this.showRegisterLink = document.getElementById('showRegister');
        this.showLoginLink = document.getElementById('showLogin');
        this.logoutBtn = document.getElementById('logoutBtn');
        
 
        this.loginFormElement = document.getElementById('loginForm');
        this.registerFormElement = document.getElementById('registerForm');
        this.editProfileForm = document.getElementById('editProfileForm');
    }

    bindEvents() {

        this.showRegisterLink?.addEventListener('click', (e) => {
            e.preventDefault();
            this.showForm('register');
        });
        
        this.showLoginLink?.addEventListener('click', (e) => {
            e.preventDefault();
            this.showForm('login');
        });
        

        this.loginFormElement?.addEventListener('submit', (e) => this.handleLogin(e));
        this.registerFormElement?.addEventListener('submit', (e) => this.handleRegister(e));
        this.editProfileForm?.addEventListener('submit', (e) => this.handleProfileUpdate(e));
        

        this.imageUpload?.addEventListener('change', (e) => this.handleImageUpload(e));
        

        this.logoutBtn?.addEventListener('click', () => this.handleLogout());
    }

    async checkAuth() {
        try {
            const response = await fetch('/api/check-auth');
            const data = await response.json();
            
            if (data.authenticated) {
                this.showProfile();
                this.loadProfileData();
            } else {
                this.showForm('login');
            }
        } catch (error) {
            console.error('Ошибка проверки авторизации:', error);
            this.showForm('login');
        }
    }

    showForm(formType) {
        this.loginForm.style.display = formType === 'login' ? 'block' : 'none';
        this.registerForm.style.display = formType === 'register' ? 'block' : 'none';
        this.profileSection.style.display = 'none';
    }

    showProfile() {
        this.loginForm.style.display = 'none';
        this.registerForm.style.display = 'none';
        this.profileSection.style.display = 'block';
    }

    async handleLogin(e) {
        e.preventDefault();
        
        const username = this.loginUsername.value;
        const password = this.loginPassword.value;
        
        try {
            const response = await fetch('/api/login', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ username, password })
            });
            
            const data = await response.json();
            
            if (response.ok) {
                this.showNotification('Вход выполнен успешно!', 'success');
                this.showProfile();
                this.loadProfileData();
            } else {
                this.showNotification(data.error || 'Ошибка входа', 'error');
            }
        } catch (error) {
            this.showNotification('Ошибка соединения', 'error');
        }
    }

    async handleRegister(e) {
        e.preventDefault();
        
        const username = this.registerUsername.value;
        const email = this.registerEmail.value;
        const password = this.registerPassword.value;
        
        try {
            const response = await fetch('/api/register', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ username, email, password })
            });
            
            const data = await response.json();
            
            if (response.ok) {
                this.showNotification('Регистрация успешна!', 'success');
                this.showProfile();
                this.loadProfileData();
            } else {
                this.showNotification(data.error || 'Ошибка регистрации', 'error');
            }
        } catch (error) {
            this.showNotification('Ошибка соединения', 'error');
        }
    }

    async loadProfileData() {
        try {
            const response = await fetch('/api/profile');
            const data = await response.json();
            
            if (response.ok) {
                const user = data.user;
                
           
                this.profileUsername.textContent = user.username;
                this.profileEmail.textContent = user.email;
                this.editUsername.value = user.username;
                this.editEmail.value = user.email;
                
                if (user.profile_image) {
                    this.profileImage.src = user.profile_image;
                } else {
                    this.profileImage.src = 'https://via.placeholder.com/150/667eea/ffffff?text=' + user.username.charAt(0).toUpperCase();
                }
            }
        } catch (error) {
            console.error('Ошибка загрузки профиля:', error);
        }
    }

    async handleProfileUpdate(e) {
        e.preventDefault();
        
        const username = this.editUsername.value;
        const email = this.editEmail.value;
        
        try {
            const response = await fetch('/api/profile', {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ username, email })
            });
            
            const data = await response.json();
            
            if (response.ok) {
                this.showNotification('Профиль обновлен!', 'success');
                this.loadProfileData();
            } else {
                this.showNotification(data.error || 'Ошибка обновления', 'error');
            }
        } catch (error) {
            this.showNotification('Ошибка соединения', 'error');
        }
    }

    async handleImageUpload(e) {
        const file = e.target.files[0];
        if (!file) return;
        
        const formData = new FormData();
        formData.append('profileImage', file);
        
        try {
            const response = await fetch('/api/profile/upload-photo', {
                method: 'POST',
                body: formData
            });
            
            const data = await response.json();
            
            if (response.ok) {
                this.showNotification('Фото профиля обновлено!', 'success');
                this.profileImage.src = data.profileImage;
            } else {
                this.showNotification(data.error || 'Ошибка загрузки', 'error');
            }
        } catch (error) {
            this.showNotification('Ошибка загрузки файла', 'error');
        }
        

        e.target.value = '';
    }

    async handleLogout() {
        try {
            const response = await fetch('/api/logout', {
                method: 'POST'
            });
            
            if (response.ok) {
                this.showNotification('Выход выполнен', 'success');
                setTimeout(() => {
                    this.showForm('login');
                    this.clearForms();
                }, 1000);
            }
        } catch (error) {
            this.showNotification('Ошибка выхода', 'error');
        }
    }

    clearForms() {
        this.loginUsername.value = '';
        this.loginPassword.value = '';
        this.registerUsername.value = '';
        this.registerEmail.value = '';
        this.registerPassword.value = '';
    }

    showNotification(message, type) {
        const notification = document.getElementById('notification');
        notification.textContent = message;
        notification.className = `notification ${type}`;
        
        setTimeout(() => {
            notification.className = 'notification';
        }, 3000);
    }
}


document.addEventListener('DOMContentLoaded', () => {
    new ProfileSystem();
});