const express = require('express');
const session = require('express-session');
const sqlite3 = require('sqlite3').verbose();
const multer = require('multer');
const path = require('path');
const bcrypt = require('bcryptjs');

const app = express();
const PORT = process.env.PORT || 3000;


app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'));
app.use('/uploads', express.static('uploads'));


app.use(session({
    secret: 'your-secret-key',
    resave: false,
    saveUninitialized: true,
    cookie: { secure: false }
}));


const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, 'uploads/');
    },
    filename: function (req, file, cb) {
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
        cb(null, 'profile-' + uniqueSuffix + path.extname(file.originalname));
    }
});

const upload = multer({
    storage: storage,
    limits: { fileSize: 5 * 1024 * 1024 }, // 5MB
    fileFilter: function (req, file, cb) {
        const filetypes = /jpeg|jpg|png|gif/;
        const mimetype = filetypes.test(file.mimetype);
        const extname = filetypes.test(path.extname(file.originalname).toLowerCase());
        
        if (mimetype && extname) {
            return cb(null, true);
        }
        cb(new Error('Только изображения разрешены!'));
    }
});


const db = new sqlite3.Database('./database.db', (err) => {
    if (err) {
        console.error('Ошибка подключения к базе данных:', err);
    } else {
        console.log('Подключение к SQLite установлено');
        initializeDatabase();
    }
});

function initializeDatabase() {
    db.run(`CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        email TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        profile_image TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )`);
}


function isAuthenticated(req, res, next) {
    if (req.session.userId) {
        next();
    } else {
        res.status(401).json({ error: 'Требуется авторизация' });
    }
}

app.post('/api/register', async (req, res) => {
    try {
        const { username, email, password } = req.body;
        
        db.get('SELECT id FROM users WHERE username = ? OR email = ?', [username, email], async (err, row) => {
            if (err) {
                return res.status(500).json({ error: 'Ошибка базы данных' });
            }
            
            if (row) {
                return res.status(400).json({ error: 'Пользователь с таким именем или email уже существует' });
            }
            
            const hashedPassword = await bcrypt.hash(password, 10);
            
            
            db.run('INSERT INTO users (username, email, password) VALUES (?, ?, ?)', 
                [username, email, hashedPassword], 
                function(err) {
                    if (err) {
                        return res.status(500).json({ error: 'Ошибка создания пользователя' });
                    }
                    
                    req.session.userId = this.lastID;
                    res.status(201).json({ 
                        message: 'Регистрация успешна',
                        userId: this.lastID 
                    });
                }
            );
        });
    } catch (error) {
        res.status(500).json({ error: 'Ошибка сервера' });
    }
});


app.post('/api/login', (req, res) => {
    const { username, password } = req.body;
    
    db.get('SELECT * FROM users WHERE username = ?', [username], async (err, user) => {
        if (err) {
            return res.status(500).json({ error: 'Ошибка базы данных' });
        }
        
        if (!user) {
            return res.status(401).json({ error: 'Неверные учетные данные' });
        }
        
        
        const isValidPassword = await bcrypt.compare(password, user.password);
        
        if (!isValidPassword) {
            return res.status(401).json({ error: 'Неверные учетные данные' });
        }
        
        
        req.session.userId = user.id;
        res.json({ 
            message: 'Авторизация успешна',
            user: {
                id: user.id,
                username: user.username,
                email: user.email,
                profileImage: user.profile_image
            }
        });
    });
});


app.get('/api/profile', isAuthenticated, (req, res) => {
    db.get('SELECT id, username, email, profile_image FROM users WHERE id = ?', 
        [req.session.userId], 
        (err, user) => {
            if (err) {
                return res.status(500).json({ error: 'Ошибка базы данных' });
            }
            
            if (!user) {
                return res.status(404).json({ error: 'Пользователь не найден' });
            }
            
            res.json({ user });
        }
    );
});

app.put('/api/profile', isAuthenticated, (req, res) => {
    const { username, email } = req.body;
    
  
    db.get('SELECT id FROM users WHERE (username = ? OR email = ?) AND id != ?', 
        [username, email, req.session.userId], 
        (err, row) => {
            if (err) {
                return res.status(500).json({ error: 'Ошибка базы данных' });
            }
            
            if (row) {
                return res.status(400).json({ error: 'Имя пользователя или email уже заняты' });
            }
           
            db.run('UPDATE users SET username = ?, email = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?', 
                [username, email, req.session.userId], 
                function(err) {
                    if (err) {
                        return res.status(500).json({ error: 'Ошибка обновления профиля' });
                    }
                    
                    res.json({ 
                        message: 'Профиль обновлен',
                        user: { username, email }
                    });
                }
            );
        }
    );
});

app.post('/api/profile/upload-photo', isAuthenticated, upload.single('profileImage'), (req, res) => {
    if (!req.file) {
        return res.status(400).json({ error: 'Файл не загружен' });
    }
    
    const profileImage = '/uploads/' + req.file.filename;
    
    db.run('UPDATE users SET profile_image = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?', 
        [profileImage, req.session.userId], 
        function(err) {
            if (err) {
                return res.status(500).json({ error: 'Ошибка обновления фото' });
            }
            
            res.json({ 
                message: 'Фото профиля обновлено',
                profileImage: profileImage
            });
        }
    );
});

app.post('/api/logout', (req, res) => {
    req.session.destroy((err) => {
        if (err) {
            return res.status(500).json({ error: 'Ошибка выхода' });
        }
        res.json({ message: 'Выход выполнен успешно' });
    });
});
app.get('/api/check-auth', (req, res) => {
    if (req.session.userId) {
        res.json({ authenticated: true, userId: req.session.userId });
    } else {
        res.json({ authenticated: false });
    }
});

app.listen(PORT, () => {
    console.log(`Сервер запущен на http://localhost:${PORT}`);
});